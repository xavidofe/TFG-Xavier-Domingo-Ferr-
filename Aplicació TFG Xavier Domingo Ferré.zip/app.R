# =====================================================================
# app.R  —  Explorador PISA per CCAA (2015–2022)
#
# Requereix al mateix directori:
#   resultats.rds, contrast.R, contrast_resum.R
#
# Desplegament a shinyapps.io:
#   rsconnect::deployApp(appFiles = c("app.R","resultats.rds",
#                                     "contrast.R","contrast_resum.R"))
# =====================================================================

library(shiny)
library(ggplot2)

resultats <- readRDS("resultats.rds")
source("contrast.R")
source("contrast_resum.R")

# Etiquetes llegibles de les variables (des de meta)
var_choices <- setNames(
  sapply(resultats$meta$vars, function(v) v$id),
  sapply(resultats$meta$vars, function(v) v$etiqueta)
)
anys      <- resultats$meta$anys
ccaa_tots <- sort(ccaa_disponibles(resultats, max(anys)))

# Avisos de comparabilitat contextuals
avis_lectura_2015 <- paste(
  "Atenció: l'OCDE no va publicar la mitjana de lectura d'Espanya el 2015",
  "per una incidència en el comportament de resposta. Interpreteu amb cautela",
  "qualsevol comparació de lectura que inclogui el 2015."
)

# ---------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------
ui <- fluidPage(
  tags$head(tags$style(HTML("
    .alerta { padding: 16px 20px; border-radius: 8px; margin: 8px 0 16px 0;
              font-size: 16px; line-height: 1.4; }
    .alerta-si { background: #e6f4ea; border-left: 6px solid #137333; color: #0b3d1c; }
    .alerta-no { background: #f1f3f4; border-left: 6px solid #80868b; color: #3c4043; }
    .alerta b { font-weight: 700; }
    .nota { font-size: 13px; color: #5f6368; margin-top: 4px; }
    .peu { font-size: 12px; color: #80868b; margin-top: 24px;
           border-top: 1px solid #e0e0e0; padding-top: 8px; }
    h2 { font-weight: 700; }
  "))),
  
  titlePanel("Explorador PISA per comunitats autònomes"),
  p("Resultats de PISA 2015, 2018 i 2022 per a Espanya, amb proves de significació estadística (BRR-Fay i regles de Rubin)."),
  
  sidebarLayout(
    sidebarPanel(
      width = 3,
      selectInput("var", "Indicador", choices = var_choices),
      uiOutput("avis_var"),
      hr(),
      radioButtons("mode", "Tipus de comparació",
                   c("Una CCAA vs Espanya"   = "vsesp",
                     "Dues CCAA entre si"     = "ccaa",
                     "Una CCAA entre anys"    = "temporal"))
    ),
    mainPanel(
      width = 9,
      conditionalPanel("input.mode == 'vsesp'",
                       selectInput("any1", "Any", choices = anys, selected = max(anys)),
                       htmlOutput("resum_text"),
                       plotOutput("plot_vsesp", height = "520px")
      ),
      conditionalPanel("input.mode == 'ccaa'",
                       fluidRow(
                         column(4, selectInput("anyC", "Any", choices = anys, selected = max(anys))),
                         column(4, selectInput("ccaaA", "Comunitat A", choices = ccaa_tots, selected = "Catalunya")),
                         column(4, selectInput("ccaaB", "Comunitat B", choices = ccaa_tots, selected = "Madrid"))
                       ),
                       uiOutput("alerta_ccaa"),
                       plotOutput("plot_ccaa", height = "320px")
      ),
      conditionalPanel("input.mode == 'temporal'",
                       selectInput("ccaaT", "Comunitat", choices = ccaa_tots, selected = "Catalunya"),
                       uiOutput("alerta_temporal"),
                       plotOutput("plot_temporal", height = "360px")
      ),
      div(class = "peu",
          textOutput("peu_text", inline = TRUE))
    )
  )
)

# ---------------------------------------------------------------------
# SERVER
# ---------------------------------------------------------------------
server <- function(input, output, session) {
  
  nom_var <- reactive({
    names(var_choices)[var_choices == input$var]
  })
  
  es_lectura <- reactive(input$var == "read")
  
  # Avís específic de variable (lectura 2015)
  output$avis_var <- renderUI({
    if (es_lectura())
      div(class = "nota", avis_lectura_2015)
  })
  
  # ---- MODE 1: totes les CCAA vs Espanya ----
  taula_resum <- reactive({
    resum_vs_espanya(resultats, input$var, as.numeric(input$any1))
  })
  
  output$resum_text <- renderUI({
    d <- taula_resum()
    n_sig  <- sum(d$signif)
    n_tot  <- nrow(d)
    HTML(sprintf(
      "<div class='alerta alerta-si'>De les %d comunitats, <b>%d</b> es desvien
       significativament de la mitjana espanyola en <b>%s</b> (%s).
       Les marcades amb «—» no presenten diferència estadísticament significativa.</div>",
      n_tot, n_sig, nom_var(), input$any1
    ))
  })
  
  output$plot_vsesp <- renderPlot({
    d <- taula_resum()
    d$CCAA <- factor(d$CCAA, levels = d$CCAA[order(d$valor)])
    esp <- d$Espanya[1]
    d$col <- ifelse(!d$signif, "ns",
                    ifelse(d$diff > 0, "sobre", "sota"))
    ggplot(d, aes(CCAA, valor, fill = col)) +
      geom_col() +
      geom_hline(yintercept = esp, linetype = "dashed", color = "#202124") +
      annotate("text", x = 1, y = esp, label = "Espanya",
               vjust = -0.5, hjust = 0, size = 3.5, color = "#202124") +
      coord_flip() +
      scale_fill_manual(values = c(sobre = "#137333", sota = "#c5221f", ns = "#bdc1c6"),
                        labels = c(sobre = "Per sobre (sig.)", sota = "Per sota (sig.)", ns = "No significatiu"),
                        name = NULL) +
      labs(x = NULL, y = nom_var()) +
      theme_minimal(base_size = 13) +
      theme(legend.position = "top")
  })
  
  # ---- MODE 2: CCAA vs CCAA ----
  res_ccaa <- reactive({
    req(input$ccaaA != input$ccaaB)
    contrast(resultats, input$var,
             gA = list(any = as.numeric(input$anyC), ccaa = input$ccaaA),
             gB = list(any = as.numeric(input$anyC), ccaa = input$ccaaB))
  })
  
  output$alerta_ccaa <- renderUI({
    if (input$ccaaA == input$ccaaB)
      return(div(class = "alerta alerta-no", "Tria dues comunitats diferents."))
    r <- res_ccaa()
    cls <- if (r$signif) "alerta-si" else "alerta-no"
    HTML(sprintf("<div class='alerta %s'>%s</div>", cls,
                 explica_contrast(r, input$ccaaA, input$ccaaB)))
  })
  
  output$plot_ccaa <- renderPlot({
    req(input$ccaaA != input$ccaaB)
    r <- res_ccaa()
    d <- data.frame(
      CCAA = c(input$ccaaA, input$ccaaB),
      valor = c(r$estA, r$estB),
      se = c(NA, NA)
    )
    ggplot(d, aes(CCAA, valor, fill = CCAA)) +
      geom_col(width = 0.6) +
      geom_text(aes(label = round(valor, 1)), vjust = -0.5, size = 4.5) +
      scale_fill_manual(values = c("#1a73e8", "#e8710a"), guide = "none") +
      labs(x = NULL, y = nom_var()) +
      theme_minimal(base_size = 13)
  })
  
  # ---- MODE 3: temporal ----
  res_temporal <- reactive({
    resum_temporal(resultats, input$var, input$ccaaT)
  })
  
  output$alerta_temporal <- renderUI({
    rt <- res_temporal()
    salts <- rt$salts
    linies <- apply(salts, 1, function(s) {
      sig <- as.logical(s["signif"])
      sprintf("%s→%s: %s%.1f (%s)", s["de"], s["a"],
              ifelse(as.numeric(s["diff"]) > 0, "+", ""),
              as.numeric(s["diff"]),
              ifelse(sig, "significatiu", "no significatiu"))
    })
    cls <- if (any(as.logical(salts$signif))) "alerta-si" else "alerta-no"
    extra <- if (es_lectura()) paste0("<div class='nota'>", avis_lectura_2015, "</div>") else ""
    HTML(sprintf("<div class='alerta %s'><b>%s</b> · %s</div>%s",
                 cls, input$ccaaT, paste(linies, collapse = " | "), extra))
  })
  
  output$plot_temporal <- renderPlot({
    rt <- res_temporal()
    d <- rt$valors
    ggplot(d, aes(factor(YEAR), valor, group = 1)) +
      geom_line(color = "#1a73e8", linewidth = 1) +
      geom_point(color = "#1a73e8", size = 4) +
      geom_text(aes(label = round(valor, 1)), vjust = -1, size = 4.5) +
      labs(x = NULL, y = nom_var()) +
      theme_minimal(base_size = 13)
  })
  
  output$peu_text <- renderText({
    sprintf("Dades: PISA %s · Estimacions amb pesos finals i 80 rèpliques BRR-Fay (Fay=0.5); rendiment amb 10 valors plausibles i regles de Rubin · Generat el %s",
            paste(range(anys), collapse = "–"), as.character(resultats$meta$generat))
  })
}

shinyApp(ui, server)
