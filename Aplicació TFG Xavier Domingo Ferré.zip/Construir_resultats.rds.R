esp_2015 <- readRDS("Bases_de_dades/units/esp_2015.rds")
esp_2018 <- readRDS("Bases_de_dades/units/esp_2018.rds")
esp_2022 <- readRDS("Bases_de_dades/units/esp_2022.rds")

# =====================================================================
# build_resultats.R  (motor Via B)
#
# Per a cada combinació CCAA × any × variable calcula:
#   - estimació puntual (pes final W_FSTUWT)
#   - estimació a cada una de les 80 rèpliques BRR-Fay
#   - (rendiment) tot l'anterior per a cadascun dels 10 PV
#
# Es desa tot a "resultats.rds" perquè l'app Shiny faci els contrastos
# exactes EN VIU (diferència rèplica a rèplica + Rubin per a PV).
#
# NO fa servir intsvy perquè aquest necessita els intermedis per rèplica,
# que les funcions d'alt nivell no exposen. La gestió de Fay (0.5) i de
# Rubin es fa explícita aquí.
# =====================================================================

library(dplyr)

setwd("C:/Users/xavid/OneDrive/Escriptori/TFG/Dades")

FAY <- 0.5          # factor de Fay de PISA
R   <- 80           # nombre de rèpliques
PVN <- 10           # nombre de valors plausibles

w_final <- "W_FSTUWT"
w_reps  <- paste0("W_FSTURWT", 1:R)

# ---------------------------------------------------------------------
# Helpers de baix nivell
# ---------------------------------------------------------------------

# Mitjana ponderada d'un vector numèric x amb pes w, ignorant NA de x.
# (els casos amb x = NA s'exclouen del numerador i del denominador)
wmean <- function(x, w) {
  ok <- !is.na(x) & !is.na(w)
  sum(x[ok] * w[ok]) / sum(w[ok])
}

# Donat un data.frame d'una cel·la (una CCAA-any, o tot Espanya) i el nom
# d'una variable NUMÈRICA o INDICADORA 0/1, retorna:
#   c(est_puntual, rep1..rep80)
# Per a proporcions, passa-li la variable ja com a 0/1 i la "mitjana"
# ÉS la proporció.
estima_simple <- function(df, var) {
  x  <- df[[var]]
  est0 <- wmean(x, df[[w_final]])
  estr <- vapply(w_reps, function(wr) wmean(x, df[[wr]]), numeric(1))
  c(est = est0, estr)
}

# Per a RENDIMENT (PV): retorna una matriu (PVN x (1+R)):
#   columna 1 = estimació puntual de cada PV (pes final)
#   columnes 2..(R+1) = estimació de cada PV a cada rèplica
estima_pv <- function(df, pv_prefix) {
  pv_cols <- paste0("PV", 1:PVN, pv_prefix)   # ex: PV1MATH..PV10MATH
  t(vapply(pv_cols, function(pc) estima_simple(df, pc), numeric(1 + R)))
}

# ---------------------------------------------------------------------
# Definició de les variables de l'eina
# ---------------------------------------------------------------------
# Cada variable: tipus + com es construeix l'objecte numèric/indicador.

# Categòriques -> indicador 0/1 (la proporció és la mitjana de l'indicador)
# Es defineixen com a funcions que reben el df i tornen un vector 0/1.
prep_indicadors <- function(df) {
  num <- function(x) if (is.factor(x)) suppressWarnings(as.numeric(as.character(x))) else as.numeric(x)
  df %>% mutate(
    .immigrant = ifelse(num(IMMIG) %in% c(2, 3), 1, 0),
    .repetidor = ifelse(num(REPEAT) == 1, 1, 0),
    .noia      = ifelse(num(ST004D01T) == 1, 1, 0),   # revisa codi de gènere!
    .publica   = ifelse(num(SCHLTYPE) == 3, 1, 0),
    .concert   = ifelse(num(SCHLTYPE) == 2, 1, 0),
    .privada   = ifelse(num(SCHLTYPE) == 1, 1, 0),
    .schsize   = num(SCHSIZE),
    .stratio   = num(STRATIO),
    .age       = num(AGE)
  )
}

# Registre de variables: nom mostrat, tipus, i com s'obté
#   tipus "prop"  -> estima_simple sobre indicador 0/1
#   tipus "mean"  -> estima_simple sobre variable contínua
#   tipus "pv"    -> estima_pv amb el prefix corresponent
vars_def <- list(
  list(id = "immigrant", etiqueta = "% immigrant (1a+2a gen.)", tipus = "prop", col = ".immigrant"),
  list(id = "repetidor", etiqueta = "% repetidors",            tipus = "prop", col = ".repetidor"),
  list(id = "noia",      etiqueta = "% noies",                 tipus = "prop", col = ".noia"),
  list(id = "publica",   etiqueta = "% en centre públic",      tipus = "prop", col = ".publica"),
  list(id = "concert",   etiqueta = "% en centre concertat",   tipus = "prop", col = ".concert"),
  list(id = "privada",   etiqueta = "% en centre privat",      tipus = "prop", col = ".privada"),
  list(id = "schsize",   etiqueta = "Mida del centre",         tipus = "mean", col = ".schsize"),
  list(id = "stratio",   etiqueta = "Ràtio alumne/professor",  tipus = "mean", col = ".stratio"),
  list(id = "age",       etiqueta = "Edat",                    tipus = "mean", col = ".age"),
  list(id = "math",      etiqueta = "Rendiment Matemàtiques",  tipus = "pv",   col = "MATH"),
  list(id = "read",      etiqueta = "Rendiment Lectura",       tipus = "pv",   col = "READ"),
  list(id = "scie",      etiqueta = "Rendiment Ciències",      tipus = "pv",   col = "SCIE")
)

# ---------------------------------------------------------------------
# Càlcul per a un cicle
# ---------------------------------------------------------------------
# Retorna una llista amb dues parts:
#   simple : data.frame llarg  -> YEAR, CCAA, var, est, rep1..rep80
#   pv     : llista niada       -> [[var]][[CCAA]] = matriu 10 x (1+80)
calcula_cicle <- function(df, any) {
  
  df <- prep_indicadors(df)
  
  # Grups: cada CCAA + "Espanya (total)"
  grups <- df %>% filter(!is.na(CCAA)) %>% distinct(CCAA) %>% pull(CCAA)
  grups <- c(grups, "Espanya (total)")
  
  subset_grup <- function(g) if (g == "Espanya (total)") df else filter(df, CCAA == g)
  
  simple_rows <- list()
  pv_store    <- list()
  
  for (v in vars_def) {
    
    if (v$tipus %in% c("prop", "mean")) {
      for (g in grups) {
        dd  <- subset_grup(g)
        est <- estima_simple(dd, v$col)            # vector 1 + 80
        simple_rows[[length(simple_rows) + 1]] <- data.frame(
          YEAR = any, CCAA = g, var = v$id,
          t(est), check.names = FALSE
        )
      }
    }
    
    if (v$tipus == "pv") {
      pv_store[[v$id]] <- list()
      for (g in grups) {
        dd <- subset_grup(g)
        pv_store[[v$id]][[g]] <- estima_pv(dd, v$col)  # matriu 10 x (1+80)
      }
    }
  }
  
  list(
    simple = bind_rows(simple_rows),
    pv     = pv_store
  )
}

# ---------------------------------------------------------------------
# Executa per als tres cicles i munta resultats.rds
# ---------------------------------------------------------------------

esp_2015 <- readRDS("Bases_de_dades/units/esp_2015.rds")
esp_2018 <- readRDS("Bases_de_dades/units/esp_2018.rds")
esp_2022 <- readRDS("Bases_de_dades/units/esp_2022.rds")

c15 <- calcula_cicle(esp_2015, 2015)
c18 <- calcula_cicle(esp_2018, 2018)
c22 <- calcula_cicle(esp_2022, 2022)

resultats <- list(
  meta = list(
    fay = FAY, R = R, PVN = PVN,
    w_final = w_final, w_reps = w_reps,
    vars = vars_def,
    anys = c(2015, 2018, 2022),
    generat = Sys.Date()
  ),
  # taula llarga per a prop/mean: YEAR, CCAA, var, est, rep1..rep80
  simple = bind_rows(c15$simple, c18$simple, c22$simple),
  # estructura niada per a rendiment: pv[[ "2022" ]][[ var ]][[ CCAA ]] = matriu 10 x 81
  pv = list("2015" = c15$pv, "2018" = c18$pv, "2022" = c22$pv)
)

saveRDS(resultats, "resultats.rds")

cat("resultats.rds creat.\n")
cat("Files a $simple:", nrow(resultats$simple), "\n")
cat("Variables:", length(vars_def), "\n")
